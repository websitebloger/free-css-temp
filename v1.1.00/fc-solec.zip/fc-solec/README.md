Blue OnePage HTML5 Business Template
========
<img src="https://raw.githubusercontent.com/websitebloger/free-css-temp/live-demo-page/7650444a-a970-11e4-91e4-6f53baebca995.jpg" />

<a href="https://websitebloger.github.io/free-css-temp/">You Buy Update Page</a>
========
Blue is a html5 one page landing page template developed based on twitter bootstrap 3.2. It can be used as show case for your Business website and Beauty &amp; Spa website.We organized file structure and descriptive comments on codes will enable your showcase easy to maintain.
