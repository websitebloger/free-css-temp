# Analog

### Replace your new tab page with a minimal analog clock

Available on the [Chrome Web Store](https://chrome.google.com/webstore/detail/analog-new-tab/kbefmcdolmelljmkgflbldffpgibmafm).

![Analog Screenshot](analog-screenshot.png)