========================



GARAGE HTML/CSS TEMPLATE 1.0



========================

Author: Web Domus ITALIA




Twitter: 
http://www.twitter.com/webdomus

Facebook: http://www.facebook.com/webdomusitalia

LinkedIn:http://www.linkedin.com/company/web-domus-italia
 
Website: http://www.webdomus.net/



========================

Link removal:

Please contact us if you want to remove the attribution in the footer. 
Template by: http://www.webdomus.net/


========================


License



- Please refer to the LICENSE.txt file



========================

This projects uses open-source components:

�	Bootstrap 3.3.6  - http://getbootstrap.com/
�	Google Font
�	Isotope PACKAGED v2.2.2 - http://isotope.metafizzy.co
�	selectordie.js -  Vst.mn
�	Fontawesome - http://fontawesome.io/


Imagines

�	Unsplash - https://unsplash.com/

Fonts -  Google Fonts
�	Open Sans - https://www.google.com/fonts/specimen/Open+Sans
�	Roboto - https://www.google.com/fonts/specimen/Roboto
�	Bebas Neue Font - http://www.dafont.com/bebas-neue.font

========================

